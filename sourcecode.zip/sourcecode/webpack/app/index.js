var React  = require('react');
var ReactDOM = require('react-dom');
var routes = require('./config/routes');

ReactDOM.render(routes, document.getElementById('app'));
ReactDOM.render(element, document.getElementById('react-app'));
ReactDOM.render(element2, document.getElementById('react-stock'));