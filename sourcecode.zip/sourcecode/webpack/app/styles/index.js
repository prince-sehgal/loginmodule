var styles = {
     transparentBg:{
         background: 'transparent'
     },
    space: { 
     marginTop: '25px', 
    } 

}

module.exports = styles;