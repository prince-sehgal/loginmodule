var React = require("react");

module.exports = React.createClass({
   render:function(){
       return(
         <form className="form well signInHeader">
               <div>
                   <p><b>Sign in to your account</b></p>
               </div>
            </form>
       )
   } 
});