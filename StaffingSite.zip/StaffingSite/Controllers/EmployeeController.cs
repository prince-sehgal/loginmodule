﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StaffingSite.Models;
using System.IO;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System.Configuration;
using StaffingSite.SqlClient;
using System.Text;

namespace StaffingSite.Controllers
{
    public class EmployeeController : Controller
    {
        private SqlConnector SqlConnector;
        public EmployeeController()
        {
            this.SqlConnector = new SqlConnector();
        }
        public ActionResult Index(string JobId)
        {
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "1")
            {
                Session["globalJobId"] = JobId;
                Positions position = new Positions();
                position.jobid = Convert.ToString(Session["globalJobId"]);
                List<Positions> Positions = SqlConnector.GetPositions(string.Empty, string.Empty);
                //Positions = (from data in Positions where DateTime.ParseExact(data.edate, "dd/MM/yyyy", null) >= DateTime.Today select data).ToList();
                position.positions = new SelectList(Positions, "_id", "title");
                Session["model"] = position;
                return View(Session["model"]);
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }

        public ActionResult Candidate(Int64 CandidateId)
        {
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "1")
            {
            Positions position = new Positions();
            position.jobid = Convert.ToString(Session["globalJobId"]);
            List<Positions> Positions = SqlConnector.GetPositions(string.Empty, string.Empty);
            Positions = (from data in Positions where DateTime.ParseExact(data.edate, "dd/MM/yyyy", null) >= DateTime.Today select data).ToList();
                // && DateTime.ParseExact(data.sdate, "dd/MM/yyyy", null) < DateTime.Today.AddDays(1)
            position.positions = new SelectList(Positions, "_id", "title");

            Session["CandidateId"] = CandidateId;

            ReferredList list = SqlConnector.GetCandidates("referenceid", string.Format("{0}", CandidateId), "referedby", Session["UserID"].ToString()).FirstOrDefault();
            if (list != null)
            {
                position.firstname = list.firstname;
                position.midname = list.midname;
                position.IsFemale = list.IsFemale;
                position.jobid = list.jobid;
                position.lastname = list.lastname;
                position.dob = list.dob;
                position.primaryskill = list.primaryskill;
                position.secondaryskill = list.secondaryskill;
                position.currentexp = list.currentexp;
                position.totalexp = list.totalexp;
                position.currentlocation = list.currentlocation;
                position.preferredlocation = list.preferredlocation;
                position.emailid = list.emailid;
                position.mobile = list.mobile;
                Session["CandidateFile"] = list.attachment;
                if (list.statusid <= 0)
                {
                    Session["isCandidateEditable"] = "true";
                }
                else {
                    Session["isCandidateEditable"] = "false";
                }
                Session["model"] = position;

                return View(Session["model"]);
            }
            else
            {
                return RedirectToAction("History");
            }
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }

        [HttpPost]
        public JsonResult IsDiversityPosition(string PositionId)
        {
            return Json(CheckDiversityPosition(PositionId), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult IsPositionAvailable(string PositionId)
        {

            return Json(CheckPositionAvailablity(PositionId), JsonRequestBehavior.AllowGet);
        }

        private bool CheckPositionAvailablity(string PositionId)
        {
            return SqlConnector.GetCandidates("jobid", PositionId, "referedby", Session["UserID"].ToString()).Count < 10;
        }

        private bool CheckDiversityPosition(string PositionId)
        {
            return SqlConnector.GetPositions("_id", PositionId).FirstOrDefault().Diversity_Position;
        }

        [HttpPost]
        public JsonResult CheckValidEmail(string emailId, string jobId)
        {
            return Json(CheckCandidateEmail(emailId,jobId), JsonRequestBehavior.AllowGet);
        }
        public string CheckCandidateEmail(string emailId, string jobId)
        {
            string statusText = "Available";
            ReferredList user = SqlConnector.GetCandidates("emailid", emailId, "jobid", jobId).FirstOrDefault();
            DateTime dateCheck = DateTime.Now.AddMonths(-3);
            List<ReferredList> ReferredList = SqlConnector.GetCandidates("emailid", emailId);
            List<ReferredList> dateLevel = ReferredList.Where(item => item.referedon > dateCheck).ToList();
            List<ReferredList> rejectedList = dateLevel.Where(item => item.statusid == 3 || item.statusid == 5).ToList();
            List<ReferredList> offeredList = dateLevel.Where(item => item.statusid == 9).ToList();
            List<ReferredList> joinedList = dateLevel.Where(item => item.statusid == 10).ToList();

            if (user != null)
            {
                statusText = "Not Available";
            }
            else if (rejectedList.Count > 0)
            {
                statusText = "Rejected";
            }
            else if (offeredList.Count > 0)
            {
                statusText = "Offered";
            }
            else if (joinedList.Count > 0)
            {
                statusText = "Joined";
            }
            return statusText;
        }
        [HttpPost]
        public JsonResult CheckValidPhone(string phone, string jobId)
        {
            return Json(CheckCandidatePhone(phone,jobId), JsonRequestBehavior.AllowGet);
        }
        public string CheckCandidatePhone(string phone, string jobId)
        {
            string statusText = "Available";
            ReferredList user = SqlConnector.GetCandidates("mobile", phone, "jobid", jobId).FirstOrDefault();
            DateTime dateCheck = DateTime.Now.AddMonths(-3);
            List<ReferredList> ReferredList = SqlConnector.GetCandidates("mobile", phone);
            List<ReferredList> dateLevel = ReferredList.Where(item => item.referedon > dateCheck).ToList();
            List<ReferredList> rejectedList = dateLevel.Where(item => item.statusid == 3 || item.statusid == 5).ToList();
            List<ReferredList> offeredList = dateLevel.Where(item => item.statusid == 9).ToList();
            List<ReferredList> joinedList = dateLevel.Where(item =>item.statusid == 10).ToList();

            if (user != null)
            {
                statusText = "Not Available";
            }
            else if (rejectedList.Count > 0)
            {
                statusText = "Rejected";
            }
            else if (offeredList.Count > 0)
            {
                statusText = "Offered";
            }
            else if (joinedList.Count > 0)
            {
                statusText = "Joined";
            }
            return statusText;
        }
        public ActionResult History()
        {
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "1")
            {
                try
                {
                    UserProfile profile = new UserProfile();
                    var result = SqlConnector.GetUserProfiles("_id", Session["UserID"].ToString()).FirstOrDefault();
                    profile.isactive = result.isactive;
                    profile.name = result.name;
                    profile._id = result._id;
                    profile.photo = result.photo;
                    profile.lob = result.lob;
                    profile.ReferedCandidatesList = SqlConnector.GetCandidates("referedby", Session["UserID"].ToString());
                    foreach (ReferredList candidate in profile.ReferedCandidatesList)
                    {
                        var job = SqlConnector.GetPositions("_id", candidate.jobid).FirstOrDefault();
                        candidate.designation = job.designation;
                        candidate.taleonumber = job.taleonumber;
                        candidate.RecruiterName = job.RecruiterName;
                    }
                    return View(profile);
                }
                catch (Exception ex)
                {
                    ViewBag.Message = ex.Message;
                    return View();
                }
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateCandidate(Positions position, HttpPostedFileBase AttachedFile)
        {
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "1")
            {
                try
                {
                    candidate obj = new candidate();
                    string fileName = Session["CandidateFile"].ToString();
                    if (AttachedFile != null)
                    {
                        fileName = fileName.Substring(0, fileName.IndexOf(".")) + Path.GetExtension(AttachedFile.FileName);
                        AttachedFile.SaveAs(Path.Combine(Server.MapPath("~/Attachments"), fileName));
                    }
                    ReferredList candidate = SqlConnector.GetCandidates("referenceid", Session["CandidateId"].ToString(), "referedby", Session["UserID"].ToString()).FirstOrDefault();
                    candidate.primaryskill = position.primaryskill;
                    candidate.secondaryskill = position.secondaryskill;
                    candidate.totalexp = position.totalexp;
                    candidate.attachment = fileName;
                    candidate.currentexp = position.currentexp;
                    candidate.currentlocation = position.currentlocation;
                    candidate.preferredlocation = position.preferredlocation;
                    SqlConnector.UpdateCandidate(candidate, "referenceid", Session["CandidateId"].ToString(), "referedby", Session["UserID"].ToString());
                }
                catch (Exception ex)
                {
                    ViewBag.Message = "Error! Please try again" + ex.Message;
                    return View();
                }
                ViewBag.Message = "Candidate details has been updated successfully";
                return View();
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(string JobId, Positions position, HttpPostedFileBase PostedFile)
        {
            string phoneStatus = string.Empty, emailStatus = string.Empty;
            if (Session["UserID"] != null && Convert.ToString(Session["UserType"]) == "1")
            {
                if (Session["globalJobId"] != null && Session["globalJobId"].ToString() != "")
                    position.jobid = string.Format("{0}", Session["globalJobId"]);
                if (CheckPositionAvailablity(position.jobid))
                {
                    phoneStatus = CheckCandidatePhone(position.mobile, position.jobid);
                    emailStatus = CheckCandidateEmail(position.emailid, position.jobid);
                    if (phoneStatus == "Available" && emailStatus == "Available")
                    {
                        //Console.WriteLine(Request.QueryString["JobId"]);
                        if (PostedFile == null)
                        {
                            ModelState.AddModelError("CustomError", "Please attach CV");
                            return View(Session["model"]);
                        }
                        var supportedTypes = new[] { "doc", "docx", "pdf" };
                        var fileExt = System.IO.Path.GetExtension(PostedFile.FileName).Substring(1);
                        if (!supportedTypes.Contains(fileExt))
                        //if (!(cvfile.ContentType == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||cvfile.ContentType == "application/pdf"))
                        {
                            ModelState.AddModelError("CustomError", "Only word document and pdf file allowed");
                            return View(Session["model"]);
                        }
                        try
                        {
                            candidate obj = new candidate();
                            string fileName = Guid.NewGuid() + Path.GetExtension(PostedFile.FileName);
                            PostedFile.SaveAs(Path.Combine(Server.MapPath("~/Attachments"), fileName));


                            long ReferenceId = SqlConnector.GetCandidates(string.Empty, string.Empty).Count + long.Parse(ConfigurationManager.AppSettings["InitialCount"]) + 1;
                            bool isCandidateSaved = SqlConnector.AddCandidate(new ReferredList()
                            {
                                jobid = position.jobid,
                                firstname = position.firstname,
                                midname = position.midname ?? "",
                                lastname = position.lastname,
                                dob = position.dob,
                                primaryskill = position.primaryskill,
                                secondaryskill = position.secondaryskill,
                                totalexp = position.totalexp,
                                currentexp = position.currentexp,
                                currentlocation = position.currentlocation,
                                preferredlocation = position.preferredlocation,
                                referedby = Session["userid"].ToString(),
                                //lob = position.lob,
                                //sublob = position.sublob,
                                lob = 0,
                                sublob = 0,
                                taleonumber = position.taleonumber,
                                mobile = position.mobile,
                                emailid = position.emailid.ToLower(),
                                attachment = fileName,
                                referedon = DateTime.Now,
                                referenceid = ReferenceId,
                                IsFemale = CheckDiversityPosition(position.jobid) ? true : position.IsFemale,
                                statusid = 0
                            });
                            if (isCandidateSaved)
                            {
                                ModelState.Clear();
                                position.jobid = string.Format("{0}", Session["globalJobId"]);
                                ViewBag.Message = string.Format("{0}", ReferenceId);
                            }
                        }
                        catch (Exception ex)
                        {
                            ViewBag.Message = "Error! Please try again. " + ex.Message;
                            return View(Session["model"]);
                        }
                        return View(Session["model"]);
                    }
                    else
                    {
                        ModelState.Clear();
                        if (emailStatus == "Not Available" || phoneStatus == "Not Available")
                        {
                            ViewBag.Message = "Error! Candidate already reffered for selected position.";
                        }
                        else if (emailStatus == "Rejected" || phoneStatus == "Rejected")
                        {
                            ViewBag.Message = "Error! Candidate already rejected in last 3 months.";
                        }
                        else if (emailStatus == "Offered" || phoneStatus == "Offered")
                        {
                            ViewBag.Message = "Error! Candidate already offered.";
                        }
                        else if (emailStatus == "Joined" || phoneStatus == "Joined")
                        {
                            ViewBag.Message = "Error! Candidate already joined.";
                        }
                        return View(Session["model"]);
                    }
                }
                else
                {
                    ModelState.Clear();
                    ViewBag.Message = "Error! You have encountered something wrong.";
                    return View(Session["model"]);
                }
            }
            else
            {
                return RedirectToAction("Login", "Home");
            }
        }
    }
}
