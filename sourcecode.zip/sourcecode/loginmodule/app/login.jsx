var React = require('react');
var ReactDOM = require('react-dom');
var LoginHomePage=require("./component/LoginHomePage.jsx");


ReactDOM.render(
  <LoginHomePage></LoginHomePage>,
  document.getElementById('app')
)