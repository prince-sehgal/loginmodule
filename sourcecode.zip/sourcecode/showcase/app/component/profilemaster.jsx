var React = require("react");
var ReactDOM = require('react-dom');
var SignInBox=require("./SignInBox.jsx");
var LogoHeader=require("./LogoHeader.jsx");
var LogoFooter=require("./LogoFooter.jsx");
var SignInBoxHeader=require("./SignInBoxHeader.jsx");

var profile = React.createClass({
   render:function(){
       return(
           <div className="container">
            <div className="row">
                <div className="logoheader">
                    <LogoHeader/>
                </div>
            </div>
            
            <div className="row">
             
                 Profile Information
                 console.log('test')
			 </div>
            <div className="row">
                <div className="navbar-fixed-bottom footer-bottom">
                    <LogoFooter/>
                </div>
            </div>
           </div>
		   
       )
   } 
});

module.exports = profile;