var React =require('react');


var ShowList = React.createClass({
    render:function(){
        var listNames = this.props.names.map(function(participants){
            return <li> {participants} </li>;
        });
        
        return (
            
            <div>
            <b>Team Members</b>
              <ul>
             {listNames}
            </ul>
            </div>
        
        
        )
    }
});

var HelloWorld = React.createClass({
    render:function(){
            
            var batch= 'Batch 5'
            var course = 'Full Stack React App Implementation'
            var participants = ['Pankaj','Prince','Neha', 'Ritu', 'Guru', 'Nisha', 'Libin','Gaurav']
            return(
            
        <div>
            <h3>Batch Name :  {batch}</h3>
                <div>
                <h3>Course Name: {course} </h3> -  <i>
                by {this.props.author}</i> 
                </div>
                <div>
                
                    <ShowList names ={participants} />
                </div>
        </div>
      )
    }
});

module.exports = HelloWorld;