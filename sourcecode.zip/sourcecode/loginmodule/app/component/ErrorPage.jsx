var React = require("react");

module.exports = React.createClass({
   render:function(){
       return(
           <div>
               <div class="row">
                   <p> Some error occured </p>
               </div>
	       </div>	   
       )
   } 
});