

var React =require('react');
var transparentBg = require('../styles').transparentBg;
var ReactRouter = require('react-router');
var Link = ReactRouter.Link;
var HelloWorld = require('../components/purefunctions.js');
var MenuExample = require('../components/navigationmenu.js');

var Home = React.createClass({
    render:function(){
        return(
            <div className = "jumbotron col-sm-6 col-sm-offset-3 text-center" style ={transparentBg}>
                <div>
                    <HelloWorld />
                </div>
            <p className = 'lead'> </p>
            <Link to='/playerOne'>
              <button type='button' className = 'btn btn-lg btn-success'>Get Started</button>
            </Link>
            </div>
        )
    }
});

module.exports =Home;