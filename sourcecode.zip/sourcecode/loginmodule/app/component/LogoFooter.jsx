var React = require("react");

module.exports = React.createClass({
   render:function(){
       return(
            <div className="navbar-fixed-bottom footer-bottom">
				<div className="copyright"> 
                   © Copyright 2016 Mercer</div>
               </div>
       )
   } 
});