var React = require("react");

module.exports = React.createClass({
   render:function(){
       return(
           <div className="navbar-fixed-top logoheader">
            <div className="copyright"> 
                  MERCER</div>
               </div>   
       )
   } 
});