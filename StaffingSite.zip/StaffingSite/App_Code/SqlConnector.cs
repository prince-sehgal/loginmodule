﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using StaffingSite.Models;
using System.Runtime.InteropServices;
using System.Globalization;

namespace StaffingSite.SqlClient
{
    public class SqlConnector : IDisposable
    {
        SqlConnection Connection = null;
        public SqlConnection GetConnection()
        {
            if (Connection == null)
            {
                Connection = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"]));
            }
            return Connection;
        }
        public bool UpdatePosition(Positions position, string columnName, string columnValue)
        {
            bool isRecordUpdated = true;
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand("UPDATE position set taleonumber = @taleonumber, grade = @grade, designation = @designation, Diversity_Position = @Diversity_Position, lob = @lob, shift = @shift, headcount = @headcount, worklocation = @worklocation, modeofinterview = @modeofinterview, RecruiterName = @RecruiterName, role = @role, skills = @skills, InterviewDetails = @InterviewDetails, sdate = @sdate, edate = @edate, publishedby = @publishedby, publishedon = @publishedon where " + columnName + " = @columnValue", con);
                cmd.Parameters.AddWithValue("@taleonumber", position.taleonumber);
                cmd.Parameters.AddWithValue("@grade", position.grade);
                cmd.Parameters.AddWithValue("@designation", position.designation);
                cmd.Parameters.AddWithValue("@Diversity_Position", position.Diversity_Position);
                cmd.Parameters.AddWithValue("@lob", position.lob);
                cmd.Parameters.AddWithValue("@shift", position.shift);
                cmd.Parameters.AddWithValue("@headcount", position.headcount);
                cmd.Parameters.AddWithValue("@worklocation", position.worklocation);
                cmd.Parameters.AddWithValue("@modeofinterview", position.modeofinterview);
                cmd.Parameters.AddWithValue("@RecruiterName", position.RecruiterName);
                cmd.Parameters.AddWithValue("@role", position.role == null ? string.Empty : position.role);
                cmd.Parameters.AddWithValue("@Skills", position.Skills == null ? string.Empty : position.Skills);
                cmd.Parameters.AddWithValue("@InterviewDetails", position.InterviewDetails == null ? string.Empty : position.InterviewDetails);
                cmd.Parameters.Add("@sdate", SqlDbType.DateTime).Value = position.sdate;
                cmd.Parameters.Add("@edate", SqlDbType.DateTime).Value = position.edate;
                cmd.Parameters.AddWithValue("@publishedby", position.publishedby);
                cmd.Parameters.Add("@publishedon", SqlDbType.DateTime).Value = DateTime.Now;
                cmd.Parameters.AddWithValue("@columnValue", columnValue);
                con.Open();
                isRecordUpdated = cmd.ExecuteNonQuery() > 0 ? true : false;
                con.Close();
            }
            return isRecordUpdated;
        }
        public bool UpdateCandidate(ReferredList candidate, string columnName, string columnValue, [Optional]string secondColumnName, [Optional] string secondColumnValue)
        {
            bool isRecordUpdated = true;
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand(string.Empty, con);
                if (secondColumnName == null)
                {
                    cmd.CommandText = "UPDATE candidate set jobid = @jobid, firstname = @firstname, midname = @midname, lastname = @lastname, dob = @dob, primaryskill = @primaryskill, secondaryskill = @secondaryskill, totalexp = @totalexp, curentexp = @curentexp, currentlocation = @currentlocation, preferredlocation = @preferredlocation, referedby = @referedby, lob = @lob, sublob = @sublob, mobile = @mobile, emailid = @emailid, attachment = @attachment, referedon = @referedon, referenceid = @referenceid, IsFemale = @IsFemale, statusid  = @statusid where " + columnName + " = @columnValue";
                }
                else
                {
                    cmd.CommandText = "UPDATE candidate set jobid = @jobid, firstname = @firstname, midname = @midname, lastname = @lastname, dob = @dob, primaryskill = @primaryskill, secondaryskill = @secondaryskill, totalexp = @totalexp, curentexp = @curentexp, currentlocation = @currentlocation, preferredlocation = @preferredlocation, referedby = @referedby, lob = @lob, sublob = @sublob, mobile = @mobile, emailid = @emailid, attachment = @attachment, referedon = @referedon, referenceid = @referenceid, IsFemale = @IsFemale, statusid  = @statusid where " + columnName + " = @columnValue AND " + secondColumnValue + "= @secondColumnValue";
                    cmd.Parameters.AddWithValue("@secondColumnValue", secondColumnValue);
                }
                cmd.Parameters.AddWithValue("@jobid", candidate.jobid);
                cmd.Parameters.AddWithValue("@firstname", candidate.firstname);
                cmd.Parameters.AddWithValue("@midname", candidate.midname);
                cmd.Parameters.AddWithValue("@lastname", candidate.lastname);
                cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = candidate.dob;
                cmd.Parameters.AddWithValue("@primaryskill", candidate.primaryskill);
                cmd.Parameters.AddWithValue("@secondaryskill", candidate.secondaryskill);
                cmd.Parameters.AddWithValue("@totalexp", candidate.totalexp);
                cmd.Parameters.AddWithValue("@curentexp", candidate.currentexp);
                cmd.Parameters.AddWithValue("@currentlocation", candidate.currentlocation);
                cmd.Parameters.AddWithValue("@preferredlocation", candidate.preferredlocation);
                cmd.Parameters.AddWithValue("@referedby", candidate.referedby);
                cmd.Parameters.AddWithValue("@lob", candidate.lob);
                cmd.Parameters.AddWithValue("@sublob", candidate.sublob);
                cmd.Parameters.AddWithValue("@mobile", candidate.mobile);
                cmd.Parameters.AddWithValue("@emailid", candidate.emailid);
                cmd.Parameters.AddWithValue("@attachment", candidate.attachment);
                cmd.Parameters.Add("@referedon", SqlDbType.DateTime).Value = candidate.referedon;
                cmd.Parameters.AddWithValue("@referenceid", candidate.referenceid);
                cmd.Parameters.AddWithValue("@IsFemale", candidate.IsFemale);
                cmd.Parameters.AddWithValue("@statusid", candidate.statusid);
                cmd.Parameters.AddWithValue("@columnValue", columnValue);
                con.Open();
                isRecordUpdated = cmd.ExecuteNonQuery() > 0 ? true : false;
                con.Close();
            }
            return isRecordUpdated;
        }
        public bool AddCandidate(ReferredList candidate)
        {
            bool isRecordInserted = true;
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO candidate (jobid,firstname,midname,lastname,dob,primaryskill,secondaryskill,totalexp,curentexp,currentlocation,preferredlocation,referedby,lob,sublob,mobile,emailid,attachment,referedon,referenceid,IsFemale,statusid) values(@jobid,@firstname,@midname,@lastname,@dob,@primaryskill,@secondaryskill,@totalexp,@curentexp,@currentlocation,@preferredlocation,@referedby,@lob,@sublob,@mobile,@emailid,@attachment,@referedon,@referenceid,@IsFemale,@statusid)", con);
                cmd.Parameters.AddWithValue("@jobid", candidate.jobid);
                cmd.Parameters.AddWithValue("@firstname", candidate.firstname);
                cmd.Parameters.AddWithValue("@midname", candidate.midname);
                cmd.Parameters.AddWithValue("@lastname", candidate.lastname);
                cmd.Parameters.Add("@dob", SqlDbType.DateTime).Value = candidate.dob;
                cmd.Parameters.AddWithValue("@primaryskill", candidate.primaryskill);
                cmd.Parameters.AddWithValue("@secondaryskill", candidate.secondaryskill);
                cmd.Parameters.AddWithValue("@totalexp", candidate.totalexp);
                cmd.Parameters.AddWithValue("@curentexp", candidate.currentexp);
                cmd.Parameters.AddWithValue("@currentlocation", candidate.currentlocation);
                cmd.Parameters.AddWithValue("@preferredlocation", candidate.preferredlocation);
                cmd.Parameters.AddWithValue("@referedby", candidate.referedby);
                cmd.Parameters.AddWithValue("@lob", candidate.lob);
                cmd.Parameters.AddWithValue("@sublob", candidate.sublob);
                cmd.Parameters.AddWithValue("@mobile", candidate.mobile);
                cmd.Parameters.AddWithValue("@emailid", candidate.emailid);
                cmd.Parameters.AddWithValue("@attachment", candidate.attachment);
                cmd.Parameters.Add("@referedon", SqlDbType.DateTime).Value = candidate.referedon;
                cmd.Parameters.AddWithValue("@referenceid", candidate.referenceid);
                cmd.Parameters.AddWithValue("@IsFemale", candidate.IsFemale);
                cmd.Parameters.AddWithValue("@statusid", candidate.statusid);
                con.Open();
                isRecordInserted = cmd.ExecuteNonQuery() > 0 ? true : false;
                con.Close();
            }
            return isRecordInserted;
        }

        public bool AddCandidateFeedback(CandidateFeedback feedback)
        {
            bool isRecordInserted = true;
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO feedback (CandidateId,statusid,Feedback,SavedBy,HrName,SavedOn,DateString) values(@CandidateId,@statusid,@Feedback,@SavedBy,@HrName,@SavedOn,@DateString)", con);
                cmd.Parameters.AddWithValue("@CandidateId", feedback.CandidateId);
                cmd.Parameters.AddWithValue("@statusid", feedback.StatusId);
                cmd.Parameters.AddWithValue("@Feedback", feedback.Feedback);
                cmd.Parameters.AddWithValue("@SavedBy", feedback.SavedBy);
                cmd.Parameters.AddWithValue("@HrName", feedback.HrName);
                cmd.Parameters.Add("@SavedOn", SqlDbType.DateTime).Value = feedback.SavedOn;
                cmd.Parameters.AddWithValue("@DateString", feedback.DateString);
                con.Open();
                isRecordInserted = cmd.ExecuteNonQuery() > 0 ? true : false;
                con.Close();
            }
            return isRecordInserted;
        }
        public bool AddPosition(Positions position)
        {
            bool isRecordInserted = true;
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO position (taleonumber,grade,designation,Diversity_Position,lob,shift,headcount,worklocation,modeofinterview,RecruiterName,role,skills,InterviewDetails,sdate,edate,publishedby,publishedon) values(@taleonumber,@grade,@designation,@Diversity_Position,@lob,@shift,@headcount,@worklocation,@modeofinterview,@RecruiterName,@role,@skills,@InterviewDetails,@sdate,@edate,@publishedby,@publishedon)", con);
                cmd.Parameters.AddWithValue("@taleonumber", position.taleonumber);
                cmd.Parameters.AddWithValue("@grade", position.grade);
                cmd.Parameters.AddWithValue("@designation", position.designation);
                cmd.Parameters.AddWithValue("@Diversity_Position", position.Diversity_Position);
                cmd.Parameters.AddWithValue("@lob", position.lob);
                cmd.Parameters.AddWithValue("@shift", position.shift);
                cmd.Parameters.AddWithValue("@headcount", position.headcount);
                cmd.Parameters.AddWithValue("@worklocation", position.worklocation);
                cmd.Parameters.AddWithValue("@modeofinterview", position.modeofinterview);
                cmd.Parameters.AddWithValue("@RecruiterName", position.RecruiterName);
                cmd.Parameters.AddWithValue("@role", position.role == null ? string.Empty : position.role);
                cmd.Parameters.AddWithValue("@Skills", position.Skills == null ? string.Empty : position.Skills);
                cmd.Parameters.AddWithValue("@InterviewDetails", position.InterviewDetails == null ? string.Empty : position.InterviewDetails);
                cmd.Parameters.Add("@sdate", SqlDbType.DateTime).Value = position.sdate;
                cmd.Parameters.Add("@edate", SqlDbType.DateTime).Value = position.edate;
                cmd.Parameters.AddWithValue("@publishedby", position.publishedby);
                cmd.Parameters.Add("@publishedon", SqlDbType.DateTime).Value = DateTime.Now;
                con.Open();
                isRecordInserted = cmd.ExecuteNonQuery() > 0 ? true : false;
                con.Close();
            }
            return isRecordInserted;
        }
        public List<Positions> GetPositions(string columnName, string columnValue)
        {
            List<Positions> positions = new List<Positions>();
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand(string.Empty, con);
                if (columnName.Equals(string.Empty))
                {
                    cmd.CommandText = "SELECT * FROM DBO.position";
                }
                else
                {
                    cmd.CommandText = "SELECT * FROM DBO.position WHERE " + columnName + " = @columnValue";
                    cmd.Parameters.AddWithValue("@columnValue", columnValue);
                }
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Positions position = new Positions();
                    position._id = Convert.ToInt64(rdr["_id"]);
                    position.taleonumber = rdr["taleonumber"].ToString();
                    position.sdate = DateTime.Parse(rdr["sdate"].ToString()).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    position.edate = DateTime.Parse(rdr["edate"].ToString()).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    position.grade = rdr["grade"].ToString();
                    position.Diversity_Position = Convert.ToBoolean(rdr["Diversity_Position"]);
                    position.designation = rdr["designation"].ToString();
                    position.lob = rdr["lob"].ToString();
                    position.headcount = Convert.ToInt64(rdr["headcount"]);
                    position.worklocation = rdr["worklocation"].ToString();

                    position.modeofinterview = rdr["modeofinterview"].ToString();
                    position.RecruiterName = rdr["RecruiterName"].ToString();
                    position.IsFemale = Convert.ToBoolean(rdr["Diversity_Position"]);
                    position.Skills = rdr["Skills"].ToString();
                    position.InterviewDetails = rdr["InterviewDetails"].ToString();
                    position.shift = rdr["shift"].ToString();
                    position.role = rdr["role"].ToString();
                    string[] worklocations = position.worklocation.Split(',');
                    foreach (string location in worklocations)
                    {
                        if (location.Trim() == "ASF")
                            position.ASF = true;
                        if (location.Trim() == "Gurgaon")
                            position.Gurgaon = true;
                        if (location.Trim() == "Noida")
                            position.Noida = true;
                    }
                    position.publishedby = rdr["publishedby"].ToString();
                    position.publishedon = Convert.ToDateTime(rdr["publishedon"]);
                    positions.Add(position);
                }
                con.Close();
            }
            return positions;
        }
        public List<CandidateFeedback> GetFeedbacks(string columnName, string columnValue)
        {
            List<CandidateFeedback> feedbacks = new List<CandidateFeedback>();
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand(string.Empty, con);
                if (columnName.Equals(string.Empty))
                {
                    cmd.CommandText = "SELECT * FROM DBO.feedback";
                }
                else
                {
                    cmd.CommandText = "SELECT * FROM DBO.feedback WHERE " + columnName + " = @columnValue";
                    cmd.Parameters.AddWithValue("@columnValue", columnValue);
                }
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CandidateFeedback feedback = new CandidateFeedback();
                    feedback._id = Convert.ToInt64(rdr["_id"]);
                    feedback.CandidateId = Convert.ToInt64(rdr["CandidateId"]);
                    feedback.StatusId = Convert.ToInt64(rdr["StatusId"]);
                    feedback.Feedback = string.Format("{0}", rdr["Feedback"]);
                    feedback.SavedBy = string.Format("{0}", rdr["SavedBy"]);
                    feedback.HrName = string.Format("{0}", rdr["HrName"]);
                    feedback.SavedOn = Convert.ToDateTime(rdr["SavedOn"]);
                    feedback.DateString = string.Format("{0}", rdr["DateString"]);
                    feedbacks.Add(feedback);
                }
                con.Close();
            }
            return feedbacks;
        }
        public List<ReferredList> GetCandidates(string columnName, string columnValue, [Optional] string secondColumnName, [Optional] string secondColumnValue)
        {
            List<ReferredList> candidates = new List<ReferredList>();
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand(string.Empty, con);
                if (columnName.Equals(string.Empty))
                {
                    cmd.CommandText = "SELECT * FROM DBO.candidate";
                }
                else
                {
                    if (secondColumnName == null)
                    {
                        cmd.CommandText = "SELECT * FROM DBO.candidate WHERE " + columnName + " = @columnValue";
                        cmd.Parameters.AddWithValue("@columnValue", columnValue);
                    }
                    else
                    {
                        cmd.CommandText = "SELECT * FROM DBO.candidate WHERE " + columnName + " = @columnValue and " + secondColumnName + " = @secondcolumnValue";
                        cmd.Parameters.AddWithValue("@columnValue", columnValue);
                        cmd.Parameters.AddWithValue("@secondcolumnValue", secondColumnValue);
                    }
                }
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ReferredList candidate = new ReferredList();
                    candidate._id = Convert.ToInt64(rdr["_id"]);
                    candidate.jobid = string.Format("{0}", rdr["jobid"]);
                    candidate.firstname = string.Format("{0}", rdr["firstname"]);
                    candidate.midname = string.Format("{0}", rdr["midname"]);
                    candidate.lastname = string.Format("{0}", rdr["lastname"]);
                    candidate.dob = DateTime.Parse(rdr["dob"].ToString()).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
                    candidate.primaryskill = string.Format("{0}", rdr["primaryskill"]);
                    candidate.secondaryskill = string.Format("{0}", rdr["secondaryskill"]);
                    candidate.totalexp = string.Format("{0}", rdr["totalexp"]);
                    candidate.currentexp = string.Format("{0}", rdr["curentexp"]);
                    candidate.currentlocation = string.Format("{0}", rdr["currentlocation"]);
                    candidate.preferredlocation = string.Format("{0}", rdr["preferredlocation"]);
                    candidate.referedby = string.Format("{0}", rdr["referedby"]);
                    candidate.lob = Convert.ToInt64(rdr["lob"]);
                    candidate.sublob = Convert.ToInt64(rdr["sublob"]);
                    candidate.mobile = string.Format("{0}", rdr["mobile"]);
                    candidate.emailid = string.Format("{0}", rdr["emailid"]);
                    candidate.attachment = string.Format("{0}", rdr["attachment"]);
                    candidate.referedon = DateTime.Parse(rdr["referedon"].ToString());
                    candidate.referenceid = Convert.ToInt64(rdr["referenceid"]);
                    candidate.IsFemale = Convert.ToBoolean(rdr["IsFemale"]);
                    candidate.statusid = Convert.ToInt64(rdr["statusid"]);
                    candidates.Add(candidate);
                }
                con.Close();
            }
            return candidates;
        }
        public List<headcount> GetHeadCounts(string countType)
        {
            List<headcount> headCounts = new List<headcount>();
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM DBO.HEADCOUNT WHERE countType = @columnValue", con);
                cmd.Parameters.AddWithValue("@columnValue", countType);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    headcount headCount = new headcount();
                    headCount._id = Convert.ToInt64(rdr["_id"]);
                    headCount.countType = rdr["countType"].ToString();
                    headCount.visits = Convert.ToInt64(rdr["visits"]);
                    headCounts.Add(headCount);
                }
                con.Close();
            }
            return headCounts;
        }
        public bool UpdateHeadCounts(headcount objHeadCount)
        {
            bool isRecordUpdated = true;
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand("UPDATE DBO.HEADCOUNT SET visits = @visits WHERE countType = @countType", con);
                cmd.Parameters.AddWithValue("@visits", objHeadCount.visits);
                cmd.Parameters.AddWithValue("@countType", objHeadCount.countType);
                con.Open();
                isRecordUpdated = cmd.ExecuteNonQuery() > 0 ? true : false;
                con.Close();
            }
            return isRecordUpdated;
        }
        public List<UserProfile> GetUserProfiles(string columnName, string columnValue)
        {
            List<UserProfile> userProfiles = new List<UserProfile>();
            using (SqlConnection con = new SqlConnection(string.Format("{0}", ConfigurationManager.ConnectionStrings["SqlConnection"])))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM DBO.USERPROFILE WHERE " + columnName + " = @columnValue", con);
                cmd.Parameters.AddWithValue("@columnValue", columnValue);
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    UserProfile userProfile = new UserProfile();
                    userProfile._id = Convert.ToInt64(rdr["_id"]);
                    userProfile.username = rdr["username"].ToString();
                    userProfile.password = rdr["username"].ToString();
                    userProfile.name = rdr["name"].ToString();
                    userProfile.lob = rdr["lob"].ToString();
                    userProfile.photo = rdr["photo"].ToString();
                    userProfile.usertype = rdr["usertype"].ToString();
                    userProfile.isactive = rdr["isactive"].ToString();
                    userProfile.employeeid = rdr["employeeid"].ToString();
                    userProfiles.Add(userProfile);
                }
                con.Close();
            }
            return userProfiles;
        }
        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }
    }
}